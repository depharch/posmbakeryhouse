# Test Credentials
# Agent writes here when creating/modifying auth credentials (admin accounts, test users).
# Testing agent reads this before auth tests. Fork/continuation agents read on startup.
- Username: `admin`
- Password: `admin`
- Role: admin
- Login endpoint: `POST /api/auth/login`
- Session endpoint: `GET /api/auth/me`
